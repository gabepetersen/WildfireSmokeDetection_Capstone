package com.example.wildfiresmokedetection;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;

public class MainScreen extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    //Used for starting the camera activity with code
    static final int REQUEST_IMAGE_CAPTURE = 1;
    //For referencing the layout of main screen
    ImageView mainScreenImage;

    /*
      Created By: William Williams
      Created On: December 8th, 2019
      Purpose: Called when the user has inputted a correct username and password
               and the Activity is originally initiated.
      Actions Completed:
   */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        // Set the reference to the main screen layout
        mainScreenImage = findViewById(R.id.image_main_screen);
    }

    /*
      Created By: William Williams
      Created On: December 8th, 2019
      Purpose: Called when the user presses the back button on the navigation bar
      Actions Completed:
            - Does nothing to prevent going back to the login page.
   */
    @Override
    public void onBackPressed()
    {
        // Do nothing to prevent user from returning to the login page
    }

    /*
      Created By: William Williams
      Created On: December 9th, 2019
      Purpose: Called when the user presses the menu button
      Actions Completed:
            - Displays the popup menu for the options menu
   */
    public void displayMenu(View v)
    {
        PopupMenu popupOptions = new PopupMenu(this, v);
        popupOptions.setOnMenuItemClickListener(MainScreen.this);
        MenuInflater inflater = popupOptions.getMenuInflater();
        inflater.inflate(R.menu.options_menu, popupOptions.getMenu());
        popupOptions.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem optionSelected)
    {
        switch(optionSelected.getItemId())
        {
            case R.id.take_pic_vid:
                capturePhoto();
                return true;
            case R.id.upload_pic_vid:
                return true;
            case R.id.view_report:
                return true;
            default:
                return false;
        }
    }

    private void capturePhoto()
    {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            Drawable imageDraw = new BitmapDrawable(getResources(), imageBitmap);
            mainScreenImage.setBackground(imageDraw);
        }
    }

    /*
      Created By: William Williams
      Created On: December 9th, 2019
      Purpose: Called when the user presses the test button
      Actions Completed:
   */
    public void beginTest(View v)
    {

    }

}
