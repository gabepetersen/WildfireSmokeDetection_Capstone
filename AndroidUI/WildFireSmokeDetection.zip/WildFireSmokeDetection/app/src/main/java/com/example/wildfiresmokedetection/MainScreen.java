package com.example.wildfiresmokedetection;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainScreen extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    //Used for starting the camera activity with code
    static final int REQUEST_IMAGE_CAPTURE = 1;
    //Used for starting the gallery activity
    static final int GALLERY_REQUEST = 2;
    //For referencing the layout of main screen
    ImageView mainScreenImage;
    ConstraintLayout mainScreenbg;
    Bitmap imageToTest;
    String imagePath;
    String lastTime;
    String lastPath;

    /*
      Created By: William Williams
      Created On: December 8th, 2019
      Purpose: Called when the user has inputted a correct username and password
               and the Activity is originally initiated.
      Actions Completed:
   */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        // Set the reference to the main screen layout
        mainScreenImage = findViewById(R.id.image_main_screen);
        mainScreenbg = findViewById(R.id.main_screen_bg);

        lastTime = null;
        lastPath = null;
    }

    /*
      Created By: William Williams
      Created On: December 8th, 2019
      Purpose: Called when the user presses the back button on the navigation bar
      Actions Completed:
            - Does nothing to prevent going back to the login page.
   */
    @Override
    public void onBackPressed()
    {
        // Do nothing to prevent user from returning to the login page
    }

    /*
      Created By: William Williams
      Created On: December 9th, 2019
      Purpose: Called when the user presses the menu button
      Actions Completed:
            - Displays the popup menu for the options menu
   */
    public void displayMenu(View v)
    {
        PopupMenu popupOptions = new PopupMenu(this, v);
        popupOptions.setOnMenuItemClickListener(MainScreen.this);
        MenuInflater inflater = popupOptions.getMenuInflater();
        inflater.inflate(R.menu.options_menu, popupOptions.getMenu());
        popupOptions.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem optionSelected)
    {
        switch(optionSelected.getItemId())
        {
            case R.id.take_pic_vid:
                capturePhoto();
                return true;
            case R.id.upload_pic_vid:
                uploadPicture();
                return true;
            case R.id.view_report:
                viewReport();
                return true;
            default:
                return false;
        }
    }

    private void capturePhoto()
    {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    private void uploadPicture()
    {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
    }

    private void viewReport()
    {
        Intent generateReport = new Intent(this, GenerateReport.class);
        generateReport.putExtra("path", lastPath);
        generateReport.putExtra("time", lastTime);

        startActivity(generateReport);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            imageToTest = (Bitmap) extras.get("data");
            mainScreenImage.setImageBitmap(imageToTest);
            mainScreenbg.setBackgroundColor(getResources().getColor(R.color.black,getTheme()));

            //mainScreenImage.setRotation(90f);
        }
        else if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK)
        {
            try {
                final Uri imageUri = data.getData();
                imagePath = imageUri.getPath();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                imageToTest = BitmapFactory.decodeStream(imageStream);
                mainScreenImage.setImageBitmap(imageToTest);
                mainScreenbg.setBackgroundColor(getResources().getColor(R.color.black,getTheme()));

                if(imageToTest.getHeight() < imageToTest.getWidth())
                {
                    mainScreenImage.setRotation(90f);
                }

            } catch (FileNotFoundException e) {
            }

        }
    }


    /*
      Created By: William Williams
      Created On: December 9th, 2019
      Purpose: Called when the user presses the test button
      Actions Completed:
   */
    public void beginTest(View v)
    {
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = df.format(c.getTime());

        lastTime = formattedDate;
        lastPath = imagePath;

        Intent generateReport = new Intent(this, GenerateReport.class);
        generateReport.putExtra("path", imagePath);
        generateReport.putExtra("time", formattedDate);

        startActivity(generateReport);
    }

}
